/**
 * Model-facing prompt text — ENGLISH ONLY, deliberately outside the `dsw`
 * locale dictionary.
 *
 * These strings are read by the MODEL, not by a human reader: the system-prompt
 * workspace sections (`sw-remote`, `tool:sw-exec`, `tool:bash`) and the remote
 * tool-output hint of `sw_status`. A model has no locale preference, and the
 * same session is frequently served to both a Chinese-UI and an English-UI
 * operator; making the prompt follow the UI language would change the model's
 * instructions with the operator's display setting and would mix languages in
 * one conversation.
 *
 * Hence the split this module encodes (see `docs/decisions/ADR-0014`):
 * - human-facing copy (client UI, and host messages a user reads) → `src/locale/`
 *   (`dsw` namespace, zh + en, key sets kept strictly equal by the static gate);
 * - model-facing copy (system-prompt sections and model tool output) → here,
 *   one English value, no `t()` lookup, no per-language variant.
 *
 * Template parameters use the same `{name}` placeholders as the dictionary and
 * are interpolated by {@link interpolate} (a placeholder whose name is absent
 * from `params` is kept verbatim, matching the framework's rule). Values carry
 * leaf facts only — never secrets.
 * @module dsh-workspace-enhancement/model-prompts
 */
/** The English prompt copy this plugin injects into a model's system prompt. */
export declare const MODEL_PROMPTS: {
    /** R4 remote emphasis paragraph (`sw-remote` section, order 90). */
    readonly remoteEmphasis: "⚠ Your current workspace is a **remote SSH workspace**: `{endpoint}:{displayPath}` (routed through the local placeholder path `{placeholderRoot}\\{connectionId}\\…`; the placeholder path you see is only a routing alias — **all commands and file operations truly happen on the remote server**, and the working directory is a POSIX absolute path).";
    /** Permission word of a read-only side workspace. */
    readonly sideFsReadOnly: "read-only";
    /** Permission word of a read-write side workspace. */
    readonly sideFsReadWrite: "read-write";
    /** Permission word of a side workspace with execution disabled. */
    readonly sideExecOff: "off";
    /** Permission word of a side workspace with execution enabled. */
    readonly sideExecOn: "on";
    /** One side-workspace line. */
    readonly sideItem: "- Side workspace **{label}**: `{rootKey}` (fs: {fs} · exec: {exec})";
    /** Side-workspace list heading (R5). */
    readonly sideHeading: "**Extra workspaces linked to this session (side directories the model can operate on directly)**:";
    /** Side-workspace permission boundary, stated honestly. */
    readonly sideNote: "Note the permission markers: read-only (fs: read-only) rejects writes, and execution disabled (exec: off) rejects running commands under that directory; for rejected operations use a workspace with permission or ask the user to adjust. Commands run in the main workspace by default; to run on another server use `sw_exec(server, command)`.";
    /** `sw_status` remote-toolbox report heading. */
    readonly envHeading: "Remote environment:";
    /** `sw_status` hint when the remote toolbox is incomplete (never auto-installs). */
    readonly envMissing: "Hint: the remote is missing {missing} — install them on the remote (for reference only; not auto-installed): rg → sudo apt-get install ripgrep; pwsh → https://aka.ms/powershell";
    /** `tool:sw-exec` section (order 105) — injected only in a remote-context session. */
    readonly sectionSwExec: "sw_exec executes a command on the specified server; workdir defaults to that server's primary workspace. Check the [exit code: N] marker of each result; investigate non-zero exits before continuing.";
    /** `tool:bash` section (order 105, win32 hosts) — injected only in a remote-context session. */
    readonly sectionWin32Bash: "The bash tool targets remote Linux workspaces; use pwsh for local (Windows) sessions. Check the [exit code: N] marker of each result.";
};
/** A key of {@link MODEL_PROMPTS}. */
export type ModelPromptKey = keyof typeof MODEL_PROMPTS;
/**
 * Interpolate `{name}` placeholders of one {@link MODEL_PROMPTS} value.
 * Same rule as the locale `lookup()`: a name present in `params` is replaced
 * by `String(value)`; anything else keeps the literal placeholder.
 * @param key - the prompt constant to render.
 * @param params - leaf template values only; never secrets.
 */
export declare function modelPrompt(key: ModelPromptKey, params?: Record<string, unknown>): string;
